package app.com.account.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import app.com.account.model.Balance;
import app.com.account.model.Transaction;
import app.com.account.repository.BalanceRepository;
import app.com.account.repository.TransactionRepository;
import app.com.account.utility.Utility;

@RestController
@RequestMapping("/api/v1")
public class Controller {
	public static final String DEPOSIT  = "DEPOSIT";
	public static final String WITHDRW = "WITHDRAW";
	
	@Autowired 
	private TransactionRepository transactionRepository;
	
	@Autowired
	private BalanceRepository balanceRepository;
	
	@GetMapping("/balances/{accountNumber}")
	public HashMap<String,Object>  getBalances(@PathVariable(value = "accountNumber") String accountNumber){
		HashMap<String, Object> response = new HashMap<String, Object>();
		Balance balance =  balanceRepository.findByAccountNumber(accountNumber);
		response.put("balance",balance);
		if(balance != null) {
			response.put("message","Account number found");
		}
		else {
			response.put("message","Account number not found");
		}
		return response;
	}
	
	@PostMapping("balances")
	public HashMap<String,Object> recordBalance(@RequestBody Balance balance) {
		HashMap<String, Object> response = new HashMap<String, Object>();
		Balance fromDb  = balanceRepository.findByAccountNumber(balance.getAccountNumber());
		
		if(fromDb != null) {
			fromDb.setBalance(balance.getBalance());
			balanceRepository.save(fromDb);
			response.put("success", true);
			response.put("message","Account updated successfully");
		}
		else {
			balanceRepository.save(balance);
			response.put("success", true);
			response.put("message","Account added successfully");
		}
		
		return response;
	}
	
	@GetMapping("/{accountNumber}/transactions")
	public HashMap<String,Object> getTransactions(
			@PathVariable(value = "accountNumber") String accountNumber,
			@RequestParam(name="type", required = false, defaultValue= "") String type,
			@RequestParam(name="from", required = false, defaultValue= "") String from,
			@RequestParam(name="to", required = false, defaultValue= "") String to,
			@RequestParam(name="custom_period", required = false, defaultValue= "") String customPeriod
			){
		
		HashMap<String, Object> response = new HashMap<String, Object>();
		List<Transaction> transactions = new ArrayList<Transaction>();
		Utility util = new Utility();
		
		Balance balance = balanceRepository.findByAccountNumber(accountNumber);
		if(balance == null) {
			response.put("message","Account number was not found");
			response.put("transactions",transactions);
			return response;
		}
		
		
		 if(customPeriod.length() > 0) {
			
			HashMap<String,Date> period = util.getPeriodFromCustom(customPeriod);
			
			if(period.get("from") == null) {
				response.put("message","Invalid Period type");
				response.put("transactions",transactions);
				return response;
			}
			
			
			
			if(type.length() != 0) {
				transactions = transactionRepository.filterAccountPeriodType(accountNumber, period.get("from"), period.get("to"), type);
			}
			else {
				transactions = transactionRepository.filterAccountPeriod(accountNumber, period.get("from"), period.get("to"));
			}
			
			
		}
		else if(from.length()!= 0 && to.length() != 0){
			Date fromDate = util.getDateFromString(from);
			Date toDate = util.getDateFromString(to);
			
			if(fromDate != null && toDate != null) {
				
				
				if(type.length() != 0) {
					
					transactions = transactionRepository.filterAccountPeriodType(accountNumber, fromDate, toDate, type);
				}
				else {
					transactions = transactionRepository.filterAccountPeriod(accountNumber, fromDate, toDate);
				}
			}
			
		}
		
		transactions =  transactionRepository.findAll();
		response.put("message","Transactions fetched successfully");
		response.put("transactions",transactions);
		
		return response;
	}
	
	
	@PostMapping("/transactions")
	public HashMap<String, Object> insertTransaction(@RequestBody Transaction transaction) {
		
		HashMap<String, Object> response = new HashMap<String, Object>();
		
		Balance balance =  balanceRepository.findByAccountNumber(transaction.getAccountNumber());
		if(balance != null) {
			double diffAmount = transaction.getAmount();
			if(transaction.getType().equals(WITHDRW)) {
				if(balance.getBalance() < transaction.getAmount()) {
					response.put("success",true);
					response.put("message", "Insufficient funds in the account");
					return response;
				}
				
				diffAmount *= -1; //to make it negative
			}
			balance.setBalance(balance.getBalance() + diffAmount);
			balanceRepository.save(balance);
			transactionRepository.save(transaction);
			
			response.put("success",true);
			response.put("message", "Transaction made successfully");
		}
		else {
			response.put("success",false);
			response.put("message", "The balance account number was not found");
		}
		
		return response;
	}

}
