package app.com.account.utility;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

public class Utility {
	
	public HashMap<String, Date>  getPeriodFromCustom(String customPeriod) {
		HashMap<String, Date> period  = new HashMap<String, Date>();
		
		Date to , from ;
		Long time = new Date().getTime();
		switch(customPeriod) {
		case "today":
			to = new Date();
			from =new Date(time - time % (24 * 60 * 60 * 1000));
			break;
		case "lastmonth":
			to = new Date();
			from =new Date(time - time % (30* 24 * 60 * 60 * 1000)); //assume last 30 days for past month
			break;
		default:
			to = null;
			from =null;
		}
		
		
		period.put("to", to);
		period.put("from", from);
		
		return  period;
	}
	
	public Date getDateFromString(String dt) {
		try {
			return new SimpleDateFormat("dd/MM/yyyy").parse(dt);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			return null;
		}
	}
}
