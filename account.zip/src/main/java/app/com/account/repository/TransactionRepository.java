package app.com.account.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import app.com.account.model.Transaction;


public interface TransactionRepository extends JpaRepository<Transaction, Long> {
	

	@Query(
			  value = "SELECT * FROM transactions t where t.accountNumber=?1 AND t.transactionTs >= ?2 AND t.transactionTs <= ?3", 
			  nativeQuery = true)
	public List<Transaction> filterAccountPeriod(String accountNumber,Date from,Date to);

	@Query(
			  value = "SELECT * FROM transactions t where t.accountNumber=?1 AND t.transactionTs >=?2 AND t.transactionTs <= ?3 AND t.type = ?4", 
			  nativeQuery = true)
	public List<Transaction> filterAccountPeriodType(String accountNumber,Date from,Date to,String type);
}
