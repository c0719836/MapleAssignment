package app.com.account.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import app.com.account.model.Balance;

@Repository
public interface BalanceRepository extends JpaRepository<Balance, Long> {
	
	
	public Balance findByAccountNumber(String accountNumber);
}
