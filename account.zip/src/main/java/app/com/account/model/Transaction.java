package app.com.account.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(name="transactions")
@EntityListeners(AuditingEntityListener.class)

public class Transaction{
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @Column(name="accountNumber",nullable=false)
    private String accountNumber;

    @Column(name="type",nullable=false)
    private String type;

    @Column(name="amount",nullable=false)
    private double amount;
    

    @Column(name="transactionTs", nullable=false)
    private Date transactionTs;


	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}


	public String getAccountNumber() {
		return accountNumber;
	}


	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}


	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}


	public double getAmount() {
		return amount;
	}


	public void setAmount(double amount) {
		this.amount = amount;
	}


	public Date getTransactionTs() {
		return transactionTs;
	}


	public void setTransactionTs(Date transactionTs) {
		this.transactionTs = transactionTs;
	}
    
    
}